/* global state, el, saveData, renderAll, renderSelects, applyTheme, showToast, showAlert, escapeHtml, normalizeText, makeId, makeCode, getRoom, getContainer, openManager */
(() => {
  const BACKUP_KEY = 'hvor-er-den-pre-cloud-backup-v1';
  const ACTIVE_HOME_KEY = 'hvor-er-den-active-cloud-home-v1';
  const IMPORTED_HOMES_KEY = 'hvor-er-den-imported-homes-v1';
  const config = window.HED_SUPABASE;
  if (!config?.url || !config?.publishableKey) return;

  const cloud = window.HEDCloud = {
    client: null,
    session: null,
    user: null,
    profile: null,
    homes: [],
    activeHomeId: localStorage.getItem(ACTIVE_HOME_KEY) || '',
    shadow: null,
    imagePaths: new Map(),
    channel: null,
    ready: false,
    loading: false,
    pushing: false,
    dirty: false,
    offlineMode: false,
    syncTimer: 0,
    reloadTimer: 0,
    localBackup: null,
  };

  const originalSaveData = saveData;
  const originalRenderProfile = renderProfile;

  saveData = function cloudAwareSaveData() {
    originalSaveData();
    if (cloud.ready && cloud.activeHomeId && !cloud.loading) schedulePush();
  };

  renderProfile = function cloudAwareRenderProfile() {
    originalRenderProfile();
    updateAccountStatus();
  };

  function validUuid(value) {
    return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(String(value || ''));
  }

  function iso(value) {
    if (!value) return null;
    if (typeof value === 'string' && value.includes('T')) return value;
    return new Date(Number(value)).toISOString();
  }

  function millis(value) {
    return value ? new Date(value).getTime() : 0;
  }

  function updateAccountStatus(label, mode = 'ok') {
    const meta = document.querySelector('#account-info .settings-meta');
    if (!meta) return;
    const text = label || (cloud.user ? (cloud.pushing ? 'Synkroniserer' : cloud.ready ? 'Synkronisert' : 'Kobler til') : 'Ikke logget inn');
    meta.innerHTML = `<span class="cloud-status-dot ${mode === 'busy' ? 'is-busy' : mode === 'error' ? 'is-error' : ''}"></span>${escapeHtml(text)}`;
  }

  function setMessage(message, isError = false) {
    const target = document.querySelector('#cloud-message');
    if (!target) return;
    target.hidden = !message;
    target.textContent = message || '';
    target.classList.toggle('is-error', isError);
  }

  function gate() {
    let node = document.querySelector('#cloud-gate');
    if (node) return node;
    node = document.createElement('div');
    node.id = 'cloud-gate';
    node.className = 'cloud-gate';
    node.hidden = true;
    node.innerHTML = '<div class="cloud-panel" id="cloud-panel"></div>';
    document.body.append(node);
    node.addEventListener('click', handleGateClick);
    node.addEventListener('submit', handleGateSubmit);
    return node;
  }

  function showGate(html) {
    gate().hidden = false;
    document.querySelector('#cloud-panel').innerHTML = html;
  }

  function hideGate() {
    gate().hidden = true;
  }

  function brandHtml() {
    return `<div class="cloud-brand"><span class="cloud-brand__mark">⌖</span><div><h1>Hvor er den?</h1><p>Finn tingene sammen.</p></div></div>`;
  }

  async function invitationPreview(code) {
    if (!code || !cloud.client) return null;
    const { data, error } = await cloud.client.rpc('invitation_preview', { p_code: code });
    if (error || !data?.[0]) return null;
    return data[0];
  }

  async function showAuthGate() {
    const inviteCode = new URLSearchParams(location.search).get('invite') || '';
    const preview = await invitationPreview(inviteCode);
    const inviteHtml = preview ? `<div class="cloud-invite-card"><strong>Invitasjon til ${escapeHtml(preview.home_name)}</strong><small>${escapeHtml(preview.inviter_name)} har invitert deg som ${preview.role === 'viewer' ? 'leser' : 'medlem'}.</small></div>` : '';
    showGate(`${brandHtml()}${inviteHtml}<div class="cloud-tabs"><button class="cloud-tab is-active" type="button" data-cloud-tab="login">Logg inn</button><button class="cloud-tab" type="button" data-cloud-tab="signup">Opprett konto</button></div><section data-cloud-auth="login"><h2 class="cloud-title">Velkommen tilbake</h2><p class="cloud-copy">Logg inn for å synkronisere hjemmet mellom telefoner.</p><form class="cloud-form" id="cloud-login-form"><label class="cloud-field"><span>E-post</span><input name="email" type="email" autocomplete="email" required /></label><label class="cloud-field"><span>Passord</span><input name="password" type="password" autocomplete="current-password" minlength="8" required /></label><button class="cloud-primary" type="submit">Logg inn</button></form></section><section data-cloud-auth="signup" hidden><h2 class="cloud-title">Opprett konto</h2><p class="cloud-copy">Kontoen brukes til felles hjem, private ting og sikker synkronisering.</p><form class="cloud-form" id="cloud-signup-form"><label class="cloud-field"><span>Navn</span><input name="name" type="text" autocomplete="name" maxlength="80" required /></label><label class="cloud-field"><span>E-post</span><input name="email" type="email" autocomplete="email" required /></label><label class="cloud-field"><span>Passord</span><input name="password" type="password" autocomplete="new-password" minlength="8" required /></label><button class="cloud-primary" type="submit">Opprett konto</button></form></section><p class="cloud-message" id="cloud-message" hidden></p><div class="cloud-divider">eller</div><button class="cloud-secondary" type="button" data-cloud-offline>Fortsett bare på denne telefonen</button>`);
  }

  function showOnboarding() {
    const localCount = state.data.items.length + state.data.deleted.length;
    const hasHomes = cloud.homes.length > 0;
    const importLabel = hasHomes ? 'Kopier ting fra det aktive hjemmet' : 'Ta med ting fra denne telefonen';
    showGate(`${brandHtml()}<h2 class="cloud-title">Lag eller bli med i et hjem</h2><p class="cloud-copy">Et hjem samler medlemmer, rom, kasser og ting.</p><div class="cloud-choice-grid"><form class="cloud-choice cloud-form" id="cloud-create-home-form"><strong>Opprett nytt hjem</strong><small>Du blir eier og kan invitere andre.</small><label class="cloud-field"><span>Navn på hjemmet</span><input name="name" type="text" value="Hjemmet vårt" maxlength="80" required /></label><label class="cloud-check"><input name="importLocal" type="checkbox" ${!hasHomes && localCount ? 'checked' : ''} /><span><strong>${importLabel}</strong><small>${localCount} ting er tilgjengelige på telefonen nå.</small></span></label><button class="cloud-primary" type="submit">Opprett hjem</button></form><form class="cloud-choice cloud-form" id="cloud-join-form"><strong>Har du en invitasjon?</strong><small>Lim inn koden eller åpne invitasjonslenken.</small><label class="cloud-field"><span>Invitasjonskode</span><input name="code" type="text" autocomplete="off" required /></label><button class="cloud-secondary" type="submit">Bli med</button></form></div><p class="cloud-message" id="cloud-message" hidden></p>${hasHomes ? '<button class="cloud-link-button" type="button" data-cloud-cancel>Tilbake til appen</button>' : ''}<button class="cloud-link-button" type="button" data-cloud-signout>Logg ut</button>`);
  }

  function showLoading(message = 'Henter hjemmet …') {
    showGate(`${brandHtml()}<h2 class="cloud-title">${escapeHtml(message)}</h2><p class="cloud-copy">Dette tar vanligvis bare noen sekunder.</p><div class="cloud-message">Kobler sikkert til databasen.</div>`);
  }

  async function handleGateClick(event) {
    const tab = event.target.closest('[data-cloud-tab]');
    if (tab) {
      document.querySelectorAll('[data-cloud-tab]').forEach((button) => button.classList.toggle('is-active', button === tab));
      document.querySelectorAll('[data-cloud-auth]').forEach((section) => { section.hidden = section.dataset.cloudAuth !== tab.dataset.cloudTab; });
      setMessage('');
      return;
    }
    if (event.target.closest('[data-cloud-offline]')) {
      cloud.offlineMode = true;
      hideGate();
      updateAccountStatus('Kun på telefonen', 'busy');
      return;
    }
    if (event.target.closest('[data-cloud-cancel]')) hideGate();
    if (event.target.closest('[data-cloud-signout]')) await signOut();
  }

  async function handleGateSubmit(event) {
    event.preventDefault();
    const form = event.target;
    const values = Object.fromEntries(new FormData(form));
    setMessage('Jobber …');
    try {
      if (form.id === 'cloud-login-form') {
        const { error } = await cloud.client.auth.signInWithPassword({ email: values.email.trim(), password: values.password });
        if (error) throw error;
      }
      if (form.id === 'cloud-signup-form') {
        const { data, error } = await cloud.client.auth.signUp({
          email: values.email.trim(),
          password: values.password,
          options: { data: { full_name: values.name.trim() }, emailRedirectTo: `${location.origin}${location.pathname}` },
        });
        if (error) throw error;
        if (!data.session) setMessage('Kontoen er opprettet. Åpne bekreftelseslenken i e-posten din, og logg deretter inn.');
      }
      if (form.id === 'cloud-create-home-form') {
        const importLocal = values.importLocal === 'on';
        const localCopy = structuredClone(state.data);
        const { data: homeId, error } = await cloud.client.rpc('create_home', { p_name: values.name.trim() });
        if (error) throw error;
        cloud.activeHomeId = homeId;
        localStorage.setItem(ACTIVE_HOME_KEY, homeId);
        if (importLocal) await importLocalData(localCopy, homeId);
        await refreshAccount({ preferredHomeId: homeId });
      }
      if (form.id === 'cloud-join-form') {
        await acceptInvite(values.code.trim());
      }
    } catch (error) {
      console.error(error);
      setMessage(friendlyError(error), true);
    }
  }

  function friendlyError(error) {
    const message = String(error?.message || error || 'Noe gikk galt');
    if (/Invalid login credentials/i.test(message)) return 'Feil e-post eller passord.';
    if (/already registered/i.test(message)) return 'Denne e-posten har allerede en konto.';
    if (/rate limit/i.test(message)) return 'For mange forsøk. Vent litt og prøv igjen.';
    return message;
  }

  async function init() {
    backupLocalData();
    updateAccountStatus('Kobler til', 'busy');
    try {
      const module = await import('https://esm.sh/@supabase/supabase-js@2');
      cloud.client = module.createClient(config.url, config.publishableKey, {
        auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true },
      });
      const { data: { session } } = await cloud.client.auth.getSession();
      cloud.session = session;
      cloud.user = session?.user || null;
      cloud.client.auth.onAuthStateChange((_event, nextSession) => {
        cloud.session = nextSession;
        cloud.user = nextSession?.user || null;
        setTimeout(() => cloud.user ? refreshAccount() : showAuthGate(), 0);
      });
      if (cloud.user) await refreshAccount();
      else await showAuthGate();
      window.addEventListener('online', () => { if (cloud.user) cloud.dirty ? pushSnapshot() : refreshAccount({ preferredHomeId: cloud.activeHomeId }); });
    } catch (error) {
      console.error('Supabase kunne ikke lastes', error);
      cloud.offlineMode = true;
      hideGate();
      updateAccountStatus('Frakoblet', 'error');
      showToast('Skyen er utilgjengelig. Appen virker fortsatt lokalt.');
    }
  }

  function backupLocalData() {
    try {
      cloud.localBackup = structuredClone(state.data);
      if (!localStorage.getItem(BACKUP_KEY)) localStorage.setItem(BACKUP_KEY, JSON.stringify(state.data));
    } catch { cloud.localBackup = state.data; }
  }

  async function refreshAccount({ preferredHomeId = '' } = {}) {
    if (!cloud.user || cloud.loading) return;
    cloud.loading = true;
    showLoading('Henter konto og hjem …');
    try {
      const inviteCode = new URLSearchParams(location.search).get('invite');
      if (inviteCode) {
        const { error } = await cloud.client.rpc('accept_invitation', { p_code: inviteCode });
        if (error) throw error;
        const url = new URL(location.href); url.searchParams.delete('invite'); history.replaceState({}, '', url);
      }
      const [{ data: memberships, error: memberError }, { data: profile, error: profileError }] = await Promise.all([
        cloud.client.from('home_members').select('home_id, role, homes(id,name,owner_id,updated_at)').order('joined_at'),
        cloud.client.from('profiles').select('id,display_name,avatar_url').eq('id', cloud.user.id).single(),
      ]);
      if (memberError) throw memberError;
      if (profileError) throw profileError;
      cloud.profile = profile;
      cloud.homes = (memberships || []).map((row) => ({ ...row.homes, role: row.role })).filter((home) => home?.id);
      if (!cloud.homes.length) {
        cloud.ready = false;
        showOnboarding();
        updateAccountStatus('Konto opprettet', 'busy');
        return;
      }
      const requested = preferredHomeId || cloud.activeHomeId;
      const home = cloud.homes.find((entry) => entry.id === requested) || cloud.homes[0];
      await loadHome(home.id);
    } catch (error) {
      console.error(error);
      hideGate();
      updateAccountStatus('Synkfeil', 'error');
      showToast(`Kunne ikke hente skydata: ${friendlyError(error)}`);
    } finally {
      cloud.loading = false;
    }
  }

  async function acceptInvite(code) {
    const { data: homeId, error } = await cloud.client.rpc('accept_invitation', { p_code: code });
    if (error) throw error;
    cloud.activeHomeId = homeId;
    localStorage.setItem(ACTIVE_HOME_KEY, homeId);
    await refreshAccount({ preferredHomeId: homeId });
  }

  async function loadHome(homeId, { silent = false } = {}) {
    if (!cloud.user) return;
    cloud.loading = true;
    if (!silent) showLoading('Synkroniserer hjemmet …');
    try {
      const home = cloud.homes.find((entry) => entry.id === homeId);
      if (!home) throw new Error('Du har ikke tilgang til dette hjemmet');
      const requests = await Promise.all([
        cloud.client.from('categories').select('*').eq('home_id', homeId).order('position').order('name'),
        cloud.client.from('rooms').select('*').eq('home_id', homeId).order('position').order('name'),
        cloud.client.from('containers').select('*').eq('home_id', homeId).order('position').order('name'),
        cloud.client.from('items').select('*').eq('home_id', homeId).order('updated_at', { ascending: false }),
        cloud.client.from('item_favorites').select('item_id').eq('user_id', cloud.user.id),
        cloud.client.from('item_images').select('*').order('sort_order'),
        cloud.client.from('activity_log').select('*, profiles!activity_log_actor_id_fkey(display_name)').eq('home_id', homeId).order('created_at', { ascending: false }).limit(150),
        cloud.client.from('home_members').select('user_id,role,joined_at,profiles!home_members_user_id_fkey(display_name,avatar_url)').eq('home_id', homeId).order('joined_at'),
      ]);
      const firstError = requests.find((entry) => entry.error)?.error;
      if (firstError) throw firstError;
      const [categories, rooms, containers, items, favorites, images, activity, members] = requests.map((entry) => entry.data || []);
      const signedImages = await signedImageMap(images, items.map((item) => item.id));
      const favoriteIds = new Set(favorites.map((entry) => entry.item_id));
      const activeItems = [];
      const deletedItems = [];
      for (const row of items) {
        const local = {
          id: row.id,
          name: row.name,
          categoryId: row.category_id || '',
          roomId: row.room_id || '',
          containerId: row.container_id || '',
          detail: row.detail || '',
          notes: row.notes || '',
          tags: row.tags || [],
          visibility: row.visibility === 'private' ? 'private' : 'home',
          favorite: favoriteIds.has(row.id),
          image: signedImages.get(row.id)?.url || '',
          createdAt: millis(row.created_at),
          updatedAt: millis(row.updated_at),
          movedAt: millis(row.updated_at),
          deletedAt: millis(row.deleted_at),
        };
        (row.deleted_at ? deletedItems : activeItems).push(local);
      }
      const previousSettings = state.data.settings;
      const previousSearches = state.data.recentSearches;
      state.data = {
        version: 4,
        items: activeItems,
        deleted: deletedItems,
        recentSearches: previousSearches || [],
        categories: categories.map((row) => ({ id: row.id, name: row.name, icon: row.icon, color: row.color, protected: row.is_system })),
        rooms: rooms.map((row) => ({ id: row.id, name: row.name, icon: row.icon, protected: row.is_system })),
        containers: containers.map((row) => ({ id: row.id, roomId: row.room_id, parentContainerId: row.parent_container_id || '', name: row.name, icon: row.icon, kind: row.kind, code: row.code, detail: row.detail || '', createdAt: millis(row.created_at) })),
        activity: activity.map(activityToLocal),
        home: {
          id: home.id,
          name: home.name,
          members: members.map((row) => ({ id: row.user_id, name: row.profiles?.display_name || 'Medlem', role: roleLabel(row.role), status: 'active', owner: row.role === 'owner' })),
        },
        settings: previousSettings || { theme: 'light' },
      };
      cloud.activeHomeId = homeId;
      localStorage.setItem(ACTIVE_HOME_KEY, homeId);
      cloud.imagePaths = signedImages;
      cloud.shadow = snapshot(state.data);
      cloud.ready = true;
      cloud.dirty = false;
      originalSaveData();
      applyTheme();
      renderSelects();
      renderAll();
      subscribe(homeId);
      hideGate();
      updateAccountStatus('Synkronisert');
    } finally {
      cloud.loading = false;
    }
  }

  function activityToLocal(row) {
    const name = row.metadata?.name || '';
    const messages = {
      created: `la til ${name || 'en ting'}`,
      updated: `oppdaterte ${name || 'en ting'}`,
      moved: `flyttet ${name || 'en ting'}`,
      deleted: `slettet ${name || 'en ting'}`,
      restored: `gjenopprettet ${name || 'en ting'}`,
      joined: 'ble med i hjemmet',
    };
    const types = { created: 'add', moved: 'move', updated: 'edit', deleted: 'delete', restored: 'restore', joined: 'edit' };
    return { id: String(row.id), type: types[row.action] || 'edit', itemId: row.entity_type === 'item' ? row.entity_id || '' : '', itemName: name, message: messages[row.action] || `gjorde en endring`, actor: row.profiles?.display_name || 'Noen', at: millis(row.created_at) };
  }

  function roleLabel(role) {
    return role === 'owner' ? 'Eier' : role === 'viewer' ? 'Lesetilgang' : 'Medlem';
  }

  async function signedImageMap(rows, visibleItemIds) {
    const visible = new Set(visibleItemIds);
    const map = new Map();
    await Promise.all(rows.filter((row) => visible.has(row.item_id) && !map.has(row.item_id)).map(async (row) => {
      const { data, error } = await cloud.client.storage.from('item-images').createSignedUrl(row.storage_path, 3600);
      if (!error && data?.signedUrl) map.set(row.item_id, { id: row.id, path: row.storage_path, url: data.signedUrl });
    }));
    return map;
  }

  function snapshot(data) {
    const map = (entries, picker) => Object.fromEntries(entries.map((entry, index) => [entry.id, picker(entry, index)]));
    return {
      homeName: data.home.name,
      categories: map(data.categories, (entry, index) => ({ name: entry.name, icon: entry.icon, color: entry.color, position: index * 10, is_system: Boolean(entry.protected) })),
      rooms: map(data.rooms, (entry, index) => ({ name: entry.name, icon: entry.icon, position: index * 10, is_system: Boolean(entry.protected) })),
      containers: map(data.containers, (entry, index) => ({ room_id: entry.roomId, parent_container_id: entry.parentContainerId || null, name: entry.name, icon: entry.icon, kind: entry.kind, code: entry.code, detail: entry.detail || null, position: index * 10 })),
      items: map([...data.items, ...data.deleted], (entry) => ({ name: entry.name, category_id: entry.categoryId || null, room_id: entry.roomId || null, container_id: entry.containerId || null, detail: entry.detail || null, notes: entry.notes || null, tags: entry.tags || [], visibility: entry.visibility === 'private' ? 'private' : 'shared', deleted_at: entry.deletedAt ? iso(entry.deletedAt) : null, image: imageFingerprint(entry) })),
      favorites: new Set(data.items.filter((entry) => entry.favorite).map((entry) => entry.id)),
    };
  }

  function imageFingerprint(item) {
    if (item.image?.startsWith('data:')) return `data:${item.image.length}:${item.image.slice(-24)}`;
    return cloud.imagePaths.get(item.id)?.path || '';
  }

  function changed(a, b) {
    return JSON.stringify(a) !== JSON.stringify(b);
  }

  function schedulePush() {
    cloud.dirty = true;
    clearTimeout(cloud.syncTimer);
    cloud.syncTimer = setTimeout(pushSnapshot, 700);
    updateAccountStatus('Venter på synk', 'busy');
  }

  async function pushSnapshot() {
    if (!cloud.ready || !cloud.user || !cloud.activeHomeId || cloud.pushing || !navigator.onLine) return;
    cloud.pushing = true;
    updateAccountStatus('Synkroniserer', 'busy');
    try {
      const current = snapshot(state.data);
      const before = cloud.shadow || { categories: {}, rooms: {}, containers: {}, items: {}, favorites: new Set(), homeName: '' };
      if (!snapshotChanged(current, before)) {
        cloud.dirty = false;
        updateAccountStatus('Synkronisert');
        return;
      }
      if (current.homeName !== before.homeName) await assert(await cloud.client.from('homes').update({ name: current.homeName }).eq('id', cloud.activeHomeId));

      await syncEntityMap('categories', current.categories, before.categories, (id, value, isNew) => ({ id, home_id: cloud.activeHomeId, ...value, ...(isNew ? { created_by: cloud.user.id } : {}) }), ['name', 'icon', 'color', 'position']);
      await syncEntityMap('rooms', current.rooms, before.rooms, (id, value, isNew) => ({ id, home_id: cloud.activeHomeId, ...value, ...(isNew ? { created_by: cloud.user.id } : {}) }), ['name', 'icon', 'position']);
      await syncEntityMap('containers', current.containers, before.containers, (id, value, isNew) => ({ id, home_id: cloud.activeHomeId, ...value, ...(isNew ? { created_by: cloud.user.id } : { updated_by: cloud.user.id }) }), ['room_id', 'parent_container_id', 'name', 'icon', 'kind', 'code', 'detail', 'position']);
      await syncItems(current.items, before.items);
      await syncFavorites(current.favorites, before.favorites || new Set());
      await syncImages(current.items, before.items);
      await deleteMissing('containers', current.containers, before.containers);
      await deleteMissing('rooms', current.rooms, before.rooms);
      await deleteMissing('categories', current.categories, before.categories);
      cloud.dirty = false;
      await loadHome(cloud.activeHomeId, { silent: true });
    } catch (error) {
      console.error('Synkronisering feilet', error);
      cloud.dirty = true;
      updateAccountStatus('Synkfeil', 'error');
      showToast(`Synkronisering feilet: ${friendlyError(error)}`);
    } finally {
      cloud.pushing = false;
    }
  }


  function snapshotChanged(current, before) {
    if (current.homeName !== before.homeName) return true;
    for (const key of ['categories', 'rooms', 'containers', 'items']) {
      if (JSON.stringify(current[key] || {}) !== JSON.stringify(before[key] || {})) return true;
    }
    const currentFav = [...(current.favorites || new Set())].sort();
    const beforeFav = [...(before.favorites || new Set())].sort();
    return JSON.stringify(currentFav) !== JSON.stringify(beforeFav);
  }

  async function syncEntityMap(table, current, before, payload, mutableColumns) {
    for (const [id, value] of Object.entries(current)) {
      if (!validUuid(id)) continue;
      const previous = before[id];
      if (!previous) {
        await assert(await cloud.client.from(table).insert(payload(id, value, true)));
      } else if (changed(value, previous)) {
        const body = Object.fromEntries(mutableColumns.map((key) => [key, value[key]]));
        if (table === 'containers') body.updated_by = cloud.user.id;
        await assert(await cloud.client.from(table).update(body).eq('id', id));
      }
    }
  }

  async function syncItems(current, before) {
    for (const [id, value] of Object.entries(current)) {
      if (!validUuid(id)) continue;
      const previous = before[id];
      const body = { name: value.name, category_id: value.category_id, room_id: value.room_id, container_id: value.container_id, detail: value.detail, notes: value.notes, tags: value.tags, visibility: value.visibility, deleted_at: value.deleted_at };
      if (!previous) {
        await assert(await cloud.client.from('items').insert({ id, home_id: cloud.activeHomeId, owner_id: cloud.user.id, created_by: cloud.user.id, updated_by: cloud.user.id, ...body }));
      } else if (changed({ ...value, image: undefined }, { ...previous, image: undefined })) {
        await assert(await cloud.client.from('items').update({ ...body, updated_by: cloud.user.id }).eq('id', id));
      }
    }
  }

  async function syncFavorites(current, before) {
    const add = [...current].filter((id) => !before.has(id));
    const remove = [...before].filter((id) => !current.has(id));
    if (add.length) await assert(await cloud.client.from('item_favorites').insert(add.map((item_id) => ({ item_id, user_id: cloud.user.id }))));
    if (remove.length) await assert(await cloud.client.from('item_favorites').delete().eq('user_id', cloud.user.id).in('item_id', remove));
  }

  async function syncImages(current, before) {
    const all = [...state.data.items, ...state.data.deleted];
    for (const item of all) {
      const currentImage = current[item.id]?.image || '';
      const previousImage = before[item.id]?.image || '';
      if (currentImage === previousImage) continue;
      const old = cloud.imagePaths.get(item.id);
      if (old) {
        await cloud.client.storage.from('item-images').remove([old.path]);
        await cloud.client.from('item_images').delete().eq('id', old.id);
        cloud.imagePaths.delete(item.id);
      }
      if (item.image?.startsWith('data:')) {
        const path = `${cloud.activeHomeId}/${item.id}/${cloud.user.id}/${crypto.randomUUID()}.jpg`;
        const blob = dataUrlToBlob(item.image);
        await assert(await cloud.client.storage.from('item-images').upload(path, blob, { contentType: 'image/jpeg', upsert: false }));
        await assert(await cloud.client.from('item_images').insert({ item_id: item.id, storage_path: path, sort_order: 0, created_by: cloud.user.id }));
      }
    }
  }

  function dataUrlToBlob(dataUrl) {
    const [header, encoded] = dataUrl.split(',');
    const mime = header.match(/data:(.*?);/)?.[1] || 'image/jpeg';
    const bytes = atob(encoded);
    const array = new Uint8Array(bytes.length);
    for (let i = 0; i < bytes.length; i += 1) array[i] = bytes.charCodeAt(i);
    return new Blob([array], { type: mime });
  }

  async function deleteMissing(table, current, before) {
    const ids = Object.keys(before || {}).filter((id) => !current[id] && validUuid(id));
    if (ids.length) await assert(await cloud.client.from(table).delete().in('id', ids));
  }

  function assert(result) {
    if (result?.error) throw result.error;
    return result;
  }

  function subscribe(homeId) {
    if (cloud.channel) cloud.client.removeChannel(cloud.channel);
    const channel = cloud.client.channel(`home-${homeId}`);
    ['homes', 'home_members', 'categories', 'rooms', 'containers', 'items', 'activity_log'].forEach((table) => {
      channel.on('postgres_changes', { event: '*', schema: 'public', table, filter: table === 'homes' ? `id=eq.${homeId}` : `home_id=eq.${homeId}` }, remoteChange);
    });
    channel.on('postgres_changes', { event: '*', schema: 'public', table: 'item_favorites', filter: `user_id=eq.${cloud.user.id}` }, remoteChange);
    channel.on('postgres_changes', { event: '*', schema: 'public', table: 'item_images' }, remoteChange);
    cloud.channel = channel.subscribe();
  }

  function remoteChange() {
    if (cloud.pushing || cloud.loading) return;
    clearTimeout(cloud.reloadTimer);
    cloud.reloadTimer = setTimeout(() => loadHome(cloud.activeHomeId, { silent: true }).catch(console.error), 650);
  }

  async function importLocalData(localData, homeId) {
    const imported = new Set(JSON.parse(localStorage.getItem(IMPORTED_HOMES_KEY) || '[]'));
    if (imported.has(homeId)) return;
    const [{ data: dbCategories }, { data: dbRooms }, { data: dbContainers }] = await Promise.all([
      cloud.client.from('categories').select('*').eq('home_id', homeId),
      cloud.client.from('rooms').select('*').eq('home_id', homeId),
      cloud.client.from('containers').select('*').eq('home_id', homeId),
    ]);
    const categoryMap = new Map();
    const roomMap = new Map();
    const containerMap = new Map();
    const categoriesByName = new Map((dbCategories || []).map((row) => [normalizeText(row.name), row.id]));
    const roomsByName = new Map((dbRooms || []).map((row) => [normalizeText(row.name), row.id]));

    for (const [position, entry] of localData.categories.entries()) {
      let id = categoriesByName.get(normalizeText(entry.name));
      if (!id) {
        id = crypto.randomUUID();
        await assert(await cloud.client.from('categories').insert({ id, home_id: homeId, name: entry.name, icon: entry.icon, color: entry.color, position: position * 10, is_system: false, created_by: cloud.user.id }));
      }
      categoryMap.set(entry.id, id);
    }
    for (const [position, entry] of localData.rooms.entries()) {
      let id = roomsByName.get(normalizeText(entry.name));
      if (!id) {
        id = crypto.randomUUID();
        await assert(await cloud.client.from('rooms').insert({ id, home_id: homeId, name: entry.name, icon: entry.icon, position: position * 10, is_system: false, created_by: cloud.user.id }));
      }
      roomMap.set(entry.id, id);
    }

    const usedCodes = new Set((dbContainers || []).map((row) => row.code));
    for (const [position, entry] of localData.containers.entries()) {
      const id = crypto.randomUUID();
      let code = entry.code || makeCode(entry.name);
      while (usedCodes.has(code)) code = makeCode(entry.name);
      usedCodes.add(code);
      await assert(await cloud.client.from('containers').insert({ id, home_id: homeId, room_id: roomMap.get(entry.roomId) || [...roomMap.values()][0], name: entry.name, icon: entry.icon, kind: entry.kind || 'Annet', code, detail: entry.detail || null, position: position * 10, created_by: cloud.user.id }));
      containerMap.set(entry.id, id);
    }

    for (const entry of [...localData.items, ...localData.deleted]) {
      const id = crypto.randomUUID();
      await assert(await cloud.client.from('items').insert({
        id,
        home_id: homeId,
        owner_id: cloud.user.id,
        created_by: cloud.user.id,
        updated_by: cloud.user.id,
        name: entry.name,
        category_id: categoryMap.get(entry.categoryId) || null,
        room_id: roomMap.get(entry.roomId) || null,
        container_id: containerMap.get(entry.containerId) || null,
        detail: entry.detail || null,
        notes: entry.notes || null,
        tags: entry.tags || [],
        visibility: entry.visibility === 'private' ? 'private' : 'shared',
        deleted_at: entry.deletedAt ? iso(entry.deletedAt) : null,
        created_at: iso(entry.createdAt) || new Date().toISOString(),
        updated_at: iso(entry.updatedAt) || new Date().toISOString(),
      }));
      if (entry.favorite && !entry.deletedAt) await assert(await cloud.client.from('item_favorites').insert({ item_id: id, user_id: cloud.user.id }));
      if (entry.image?.startsWith('data:')) {
        const path = `${homeId}/${id}/${cloud.user.id}/${crypto.randomUUID()}.jpg`;
        await assert(await cloud.client.storage.from('item-images').upload(path, dataUrlToBlob(entry.image), { contentType: 'image/jpeg' }));
        await assert(await cloud.client.from('item_images').insert({ item_id: id, storage_path: path, sort_order: 0, created_by: cloud.user.id }));
      }
    }
    imported.add(homeId);
    localStorage.setItem(IMPORTED_HOMES_KEY, JSON.stringify([...imported]));
  }

  async function switchHome(homeId) {
    if (!cloud.homes.some((entry) => entry.id === homeId)) return;
    if (cloud.dirty) await pushSnapshot();
    cloud.activeHomeId = homeId;
    localStorage.setItem(ACTIVE_HOME_KEY, homeId);
    el.settingsSheet.close();
    await loadHome(homeId);
  }

  async function signOut() {
    if (cloud.client) await cloud.client.auth.signOut();
    cloud.ready = false;
    cloud.user = null;
    cloud.session = null;
    cloud.homes = [];
    if (cloud.channel) cloud.client.removeChannel(cloud.channel);
    const backup = localStorage.getItem(BACKUP_KEY);
    state.data = backup ? normalizeData(JSON.parse(backup)) : defaultData();
    originalSaveData();
    applyTheme(); renderSelects(); renderAll();
    await showAuthGate();
  }

  window.openAccountSheet = function openAccountSheet() {
    if (!cloud.user) { showAuthGate(); return; }
    state.manager = 'account';
    el.settingsSheetTitle.textContent = 'Konto og synkronisering';
    el.settingsSheetContent.innerHTML = `<div class="manager-header-card"><strong>${escapeHtml(cloud.profile?.display_name || cloud.user.email)}</strong><p>${escapeHtml(cloud.user.email || '')}<br />Endringer lagres i Supabase og synkroniseres mellom medlemmer.</p></div><span class="card-overline">DINE HJEM</span><div class="cloud-account-list">${cloud.homes.map((home) => `<div class="cloud-home-row"><span><strong>${escapeHtml(home.name)}</strong><small>${roleLabel(home.role)}${home.id === cloud.activeHomeId ? ' · Aktivt' : ''}</small></span>${home.id === cloud.activeHomeId ? '<span class="settings-meta">Valgt</span>' : `<button type="button" data-cloud-switch-home="${home.id}">Bytt</button>`}</div>`).join('')}</div><button class="manager-add-button" type="button" data-cloud-new-home><svg><use href="#i-plus" /></svg>Nytt hjem</button><button class="manager-add-button" type="button" data-cloud-join-home><svg><use href="#i-users" /></svg>Bli med via kode</button><button class="settings-row" type="button" data-cloud-import-local><span class="settings-icon"><svg><use href="#i-upload" /></svg></span><span>Importer data fra denne telefonen</span><svg class="chevron"><use href="#i-chevron" /></svg></button><button class="danger-button" type="button" data-cloud-signout-account>Logg ut</button>`;
    if (!el.settingsSheet.open) el.settingsSheet.showModal();
  };

  const originalRenderHomeManager = renderHomeManager;
  renderHomeManager = function realHomeManager() {
    if (!cloud.ready) return originalRenderHomeManager();
    const active = cloud.homes.find((home) => home.id === cloud.activeHomeId);
    const isOwner = active?.role === 'owner';
    el.settingsSheetTitle.textContent = 'Hjem og medlemmer';
    el.settingsSheetContent.innerHTML = `<div class="manager-header-card"><strong>Felles hjem</strong><p>Alle medlemmer ser delte ting og endringer i sanntid. Private ting vises bare for eieren.</p></div><form class="home-settings-form" id="home-name-form"><label class="field"><span>Navn på hjemmet</span><input id="home-name-input" type="text" maxlength="80" value="${escapeHtml(state.data.home.name)}" required ${isOwner ? '' : 'disabled'} /></label>${isOwner ? '<button class="primary-small-button" type="submit">Lagre navn</button>' : ''}</form><span class="card-overline">MEDLEMMER</span><div class="member-list">${state.data.home.members.map((member) => `<div class="member-row"><span class="member-avatar">${escapeHtml(initials(member.name))}</span><span><strong>${escapeHtml(member.name)}</strong><small>${escapeHtml(member.role)}</small></span>${member.owner || !isOwner ? '<span class="settings-meta">'+(member.owner ? 'Eier' : '')+'</span>' : `<button class="member-remove" type="button" data-remove-member="${escapeHtml(member.id)}">Fjern</button>`}</div>`).join('')}</div>${isOwner ? `<span class="card-overline">INVITER</span><form class="invite-form" id="invite-form"><input id="invite-name" type="email" placeholder="E-post, valgfritt" /><select id="invite-role"><option value="member">Medlem</option><option value="viewer">Lesetilgang</option></select><button class="primary-small-button" type="submit">Lag invitasjon</button></form><p class="invite-note">Du får en lenke som kan sendes på melding.</p>` : '<p class="invite-note">Bare eieren kan invitere og administrere medlemmer.</p>'}`;
  };

  saveHomeName = async function saveCloudHomeName(event) {
    event.preventDefault();
    const name = document.querySelector('#home-name-input')?.value.trim();
    if (!name) return;
    try {
      await assert(await cloud.client.from('homes').update({ name }).eq('id', cloud.activeHomeId));
      state.data.home.name = name;
      originalSaveData(); renderAll(); renderHomeManager(); showToast('Hjemmet er oppdatert');
    } catch (error) { showToast(friendlyError(error)); }
  };

  addPrototypeMember = async function createRealInvitation(event) {
    event.preventDefault();
    const email = document.querySelector('#invite-name')?.value.trim() || null;
    const role = document.querySelector('#invite-role')?.value || 'member';
    try {
      const { data, error } = await cloud.client.rpc('create_invitation', { p_home_id: cloud.activeHomeId, p_email: email, p_role: role, p_expires_days: 7 });
      if (error) throw error;
      const code = data?.[0]?.code;
      const link = `${location.origin}${location.pathname}?invite=${encodeURIComponent(code)}`;
      if (navigator.share) {
        try { await navigator.share({ title: `Invitasjon til ${state.data.home.name}`, text: `Bli med i ${state.data.home.name} i Hvor er den?`, url: link }); }
        catch (error) { if (error.name !== 'AbortError') await navigator.clipboard.writeText(link); }
      } else await navigator.clipboard.writeText(link);
      showAlert({ title: 'Invitasjonen er klar', html: `<p>Send denne lenken til personen du vil invitere:</p><p><strong>${escapeHtml(link)}</strong></p><p>Lenken utløper etter 7 dager.</p>` });
    } catch (error) { showToast(friendlyError(error)); }
  };

  removeMember = async function removeCloudMember(userId) {
    try {
      await assert(await cloud.client.from('home_members').delete().eq('home_id', cloud.activeHomeId).eq('user_id', userId));
      await loadHome(cloud.activeHomeId, { silent: true });
      renderHomeManager(); showToast('Medlemmet er fjernet');
    } catch (error) { showToast(friendlyError(error)); }
  };

  document.addEventListener('click', async (event) => {
    const switcher = event.target.closest('[data-cloud-switch-home]');
    if (switcher) await switchHome(switcher.dataset.cloudSwitchHome);
    if (event.target.closest('[data-cloud-new-home]')) { el.settingsSheet.close(); showOnboarding(); }
    if (event.target.closest('[data-cloud-join-home]')) { el.settingsSheet.close(); showOnboarding(); }
    if (event.target.closest('[data-cloud-signout-account]')) await signOut();
    if (event.target.closest('[data-cloud-import-local]')) {
      const backup = localStorage.getItem(BACKUP_KEY);
      if (!backup) return showToast('Fant ingen eldre lokale data');
      try { await importLocalData(normalizeData(JSON.parse(backup)), cloud.activeHomeId); await loadHome(cloud.activeHomeId); showToast('Lokale data er importert'); }
      catch (error) { showToast(friendlyError(error)); }
    }
  });

  window.HEDCloudInit = init;
  setTimeout(init, 0);
})();
